import javax.swing.*;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;

public class StuckInTheMud {
  public static void main(String[] args) { 
    welcome();
   //User inputs how many players are entering the game.
   String scoresString = JOptionPane.showInputDialog("How many people are playing? ");
    int scores = Integer.parseInt(scoresString); //Converting from a String to {int}.

    String result;
    int Playerscore;

    ArrayList <Integer> winner = new ArrayList <Integer> (scores);
    System.out.println(scores);
    for (int i = 1; i <= scores; i++) {
      Playerscore = playGame();  //add a for loop to add the appropriate Integers.
      result = "Player " + i + " your score is " + Playerscore;
      winner.add(i - 1, Playerscore); // adds the scores to the arraylist
      JOptionPane.showMessageDialog(null, result);
    }

    int playerWhoWon = 0;
    for (int k = 0; k < winner.size(); k++) {
      if (winner.get(k) > winner.get(playerWhoWon)) { // checks if next player has higher score
        playerWhoWon = k;
      }
    }
   playerWhoWon = playerWhoWon + 1;
    JOptionPane.showMessageDialog(null, "Player " + playerWhoWon + " wins!");
    JOptionPane.showMessageDialog(null, "Thanks for playing!");
  } // end main

public static void welcome() { //Welcome the players and then explain the rules of the game.
  String welcome = "Welcome to Stuck in the Mud! You have 3 dice to roll and collect points; if you roll a 2 or 5 you lose the dice. Roll the dice until you have 0 dice! Have Fun!!";
  JOptionPane.showMessageDialog(null, welcome); //a pop question will apear when running the code.
  //JOptionPane.showMessageDialog (message for the players.)
}

public static int playGame() {
  int dice = 3;
  int landing;
  Random rand = new Random();
  int score = 0;
  while (dice > 0) { //add a while loop
    for (int i = 1; i <= dice; i++) { //Use if statements to organize the score method used in
      //game for the players.
      landing = rand.nextInt(6) + 1;
          if (landing == 1) { //if landing occurs on side 1, adds  1 point.
            side1();
            score +=1;
          } // end if side1
          if (landing == 2) { //if landing occurs on 2, don't add points.
            side2();
            dice--;
          } // end if side1
          if (landing == 3) { //if landing occurs on 3, add 3 points to score.
            side3();
            score +=3;
          } // end if side1
          if (landing == 4) { //if landing occurs on 4, add 4 points to score.
            side4();
            score +=4;
          } // end if side1
          if (landing == 5) { //if landing occurs on 5, don't add points.
            side5();
            dice--;
          } // end if side1
          if (landing == 6) { //if landing occurs on 6, add 6 points to score.
            side6();
            score +=6;
          } // end if side1
    }

    JOptionPane.showMessageDialog(null, "Your score after this round is " + score); //This message is to sum up the points for this part.
    JOptionPane.showMessageDialog(null, "You still have " + dice + " dice left!"); //add a message for informing the players their remaining dice.
  }
    JOptionPane.showMessageDialog(null, "Your final score is " + score + "!"); //add all the points and provide the score for the players.
//The score for this round JOptionPane.showMessageDialog (null, "You score after this round is", score calculated.)
    return score;
}


public static void side1() { 
      //function side1() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("one.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic); //add picture to make the game more entertainment
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);

    } // end side1

public static void side2() { 
      //function side2() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("two.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic); //add picture to make the game more entertaining.
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);
      JOptionPane.showMessageDialog(null, "Sorry you rolled a 2 so you lost this dice!");

   } // end side2


public static void side3() { 
      //function side3() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("three.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic); //add picture to make the game more entertaining.
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);

    } // end side3

public static void side4() { 
      //function side4() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("four.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic); //add picture to make the game more entertaining.
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);

   } // end side4

public static void side5() { 
      //function side5() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("five.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic);//add picture to make the game more entertaining.
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);
      JOptionPane.showMessageDialog(null, "Sorry you rolled a 5 so you lost this dice!");

    } // end side5

public static void side6() { 
      //function side6() below:
      JPanel panel = new JPanel(); // creates a new panel
      ImageIcon pic = new ImageIcon("six.png"); //stores the corresponding side of the die
      JLabel label = new JLabel(pic);//add picture to make the game more entertaining.
      panel.add(label);
      JOptionPane.showMessageDialog(null, panel);

    } // end side 6
  } // end class
